﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO.Pipes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IOSExecutor_remakle
{
    public partial class Form1 : Form
    {
        public Point mouseLocation;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            mouseLocation = new Point(-e.X, -e.Y);
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Point mousePose = Control.MousePosition;
                mousePose.Offset(mouseLocation.X, mouseLocation.Y);
                Location = mousePose;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Process.Start("Injector.exe");
        }

        private async Task SendScript(string script)
        {
            using (NamedPipeClientStream pipeClient = new NamedPipeClientStream(".", "SkibidiToiletSaidAUWAndNowSkibidiToiletSad", PipeDirection.Out))
            {
                try
                {
                    await pipeClient.ConnectAsync();

                    byte[] scriptBytes = Encoding.UTF8.GetBytes(script);

                    await pipeClient.WriteAsync(scriptBytes, 0, scriptBytes.Length);

                    pipeClient.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Fehler beim Senden des Scripts: {ex.Message}");
                }
            }
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            string script = richTextBox1.Text;
            await SendScript(script);
        }
    }
}
